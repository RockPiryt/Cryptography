package main



import (
	"bufio"
	"flag"
	"fmt"
	"os"
	"log"
	"strconv"
	"strings"
	"unicode"
	
)

//Author: Paulina Kimak



// Function to count selected flags
func CountSelectedFlags(flags []*bool) int {
	count := 0
	for _, f := range flags {
		if *f {
			count++
		}
	}
	return count
}

// Function to read text from txt file
func GetText(filename string) ([]string, error) {
	var lines []string

	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		//fmt.Printf("Odczytano linię: %s\n", line)
		lineAng := RemovePolishLetters(line)
		//fmt.Printf("Po usunięciu polskich liter: %s\n", lineAng)
		lines = append(lines, lineAng)
	}

	err = file.Close()
	if err != nil {
		return nil, err
	}

	if scanner.Err() != nil{
		return nil, scanner.Err()
	}
	
	return lines, nil
}

// Function to remove Polish letters from text
func RemovePolishLetters(input string) string {
	// Mapa polskich liter z diakrytykami na ich odpowiedniki w alfabecie łacińskim
	replacementMap := map[rune]rune{
		'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z',
		'Ą': 'A', 'Ć': 'C', 'Ę': 'E', 'Ł': 'L', 'Ń': 'N', 'Ó': 'O', 'Ś': 'S', 'Ź': 'Z', 'Ż': 'Z',
	}

	// Iterate through each character in the input string and replace if it's a Polish letter
	var result strings.Builder
	for _, r := range input {
		// If the character is a Polish letter, replace it
		if repl, found := replacementMap[r]; found {
			result.WriteRune(repl)
		} else if unicode.IsLetter(r) || unicode.IsSpace(r) || unicode.IsDigit(r) {
			// If it's a letter, digit, or space, keep it
			result.WriteRune(r)
		}
	}

	return result.String()
}

func SaveOutput(result string, outputFile string) {
	// Check if the file exists
	if _, err := os.Stat(outputFile); os.IsNotExist(err) {
		// Create the file if it does not exist
		file, err := os.Create(outputFile)
		if err != nil {
			log.Fatalf("Błąd przy tworzeniu pliku: %v", err)
		}
		file.Close()
	}

	// Write the result to the file
	err := os.WriteFile(outputFile, []byte(result), 0644)
	if err != nil {
		log.Fatalf("Błąd przy zapisywaniu wyniku: %v", err)
	}

	//fmt.Println("Zapisano wynik do pliku:", outputFile)
}

// Function to create a new file (extra.txt) containing the first two characters from plain.txt
func CreateExtraFile() error {
	// Check if extra.txt already exists
	if _, err := os.Stat("files/extra.txt"); err == nil {
		// If the file exists, print a message and return
		log.Println("Plik extra.txt już istnieje.")
		return nil
	} else if !os.IsNotExist(err) {
		// If an error occurs other than "file does not exist", return the error
		log.Printf("błąd przy sprawdzaniu istnienia pliku extra.txt: %v", err)
		return fmt.Errorf("błąd przy sprawdzaniu istnienia pliku extra.txt: %v", err)
	}

	// Read the text from plain.txt
	lines, err := GetText("files/plain.txt")
	if err != nil {
		log.Printf("błąd przy odczycie pliku plain.txt: %v", err)
		return fmt.Errorf("błąd przy odczycie pliku plain.txt: %v", err)
	}

	// Check if we have at least one line in the file
	if len(lines) == 0 {
		log.Println("plik plain.txt jest pusty")
		return fmt.Errorf("plik plain.txt jest pusty")
	}

	// Get the first two characters from the first line
	line := lines[0]
	if len(line) < 2 {
		log.Println("pierwsza linia w pliku plain.txt zawiera mniej niż dwa znaki")
		return fmt.Errorf("pierwsza linia w pliku plain.txt zawiera mniej niż dwa znaki")
	}

	// Get the first two characters
	extraText := line[:2]

	// Write the extracted text to extra.txt
	err = os.WriteFile("files/extra.txt", []byte(extraText), 0644)
	if err != nil {
		log.Printf("błąd przy zapisywaniu do pliku extra.txt: %v", err)
		return fmt.Errorf("błąd przy zapisywaniu do pliku extra.txt: %v", err)
	}

	return nil
}
// ValidateKey reads and validates the keys for both Caesar and Affine ciphers from a file.
func ValidateKey(filePath string, cipherType string) (int, int) {
	// Read the key from the file.
	keyLines, err := GetText(filePath)
	if err != nil {
		fmt.Printf("Błąd przy odczycie pliku klucza: %v\n", err)
		return -1, -1
	}

	// Ensure the file contains exactly one line.
	if len(keyLines) != 1 {
		fmt.Printf("Błędny klucz: Plik klucza powinien zawierać tylko jedną linię. Znaleziono: %d\n", len(keyLines))
		return -1, -1
	}

	// Split the line into two space-separated numbers.
	parts := strings.Fields(keyLines[0])
	if len(parts) != 2 {
		fmt.Printf("Błędny klucz: Plik klucza musi zawierać dokładnie dwie liczby oddzielone spacją (np. '3 7'). Znaleziono: %s\n", keyLines[0])
		return -1, -1
	}

	// Convert the first number (always used for Caesar and Affine).
	c, err := strconv.Atoi(parts[0])
	if err != nil {
		fmt.Printf("Błędny klucz Cezara: Musi być liczbą całkowitą. Znaleziono: %s\n", parts[0])
		return -1, -1
	}

	// Validate the Caesar cipher key (0-25).
	if c < 0 || c > 25 {
		fmt.Printf("Błędny klucz Cezara: Klucz musi być liczbą z zakresu 0-25. Znaleziono: %d\n", c)
		return -1, -1
	}

	// If Caesar cipher is used, return only the first key, ignoring the second.
	if cipherType == "caesar" {
		return c, -1
	}

	// If the cipherType is not "caesar" or "affine", report an error.
	if cipherType != "affine" {
		fmt.Printf("Błędny typ szyfru: Oczekiwano 'caesar' lub 'affine', znaleziono: %s\n", cipherType)
		return -1, -1
	}

	// Convert the second number (used only for Affine cipher).
	a, err := strconv.Atoi(parts[1])
	if err != nil {
		fmt.Printf("Błędny klucz afiniczny: Musi być liczbą całkowitą. Znaleziono: %s\n", parts[1])
		return -1, -1
	}

	// Validate that 'a' is coprime with 26 and is in the range [1, 25].
	m := 26
	if a < 1 || a > 25 {
		fmt.Printf("Błędny klucz afiniczny: 'a' musi być liczbą z zakresu 1-25. Znaleziono: %d\n", a)
		return -1, -1
	}

	// Check that 'a' is coprime with 26 (gcd(a, 26) == 1).
	gcd, _, _ := ExtendedGCD(a, m)
	if gcd != 1 {
		fmt.Printf("Błędny klucz afiniczny: Współczynnik 'a' musi być względnie pierwsza z 26. Znaleziono: %d\n", a)
		return -1, -1
	}

	// Return both values: c (for Caesar) and a (for Affine).
	return c, a
}

// Extended Euclidean algorithm
func ExtendedGCD(a, b int) (int, int, int) {
	if b == 0 {
		return a, 1, 0
	}
	gcd, x1, y1 := ExtendedGCD(b, a%b)
	x := y1
	y := x1 - (a/b)*y1
	return gcd, x, y
}

// ModInverseExtended calculates the modular inverse of a mod m using the extended Euclidean algorithm.
// If the modular inverse does not exist, it returns an error.
func ModInverseExtended(a, m int) (int, error) {
	gcd, x, _ := ExtendedGCD(a, m)
	if gcd != 1 {
		return 0, fmt.Errorf("brak modularnej odwrotności dla a=%d (mod %d)", a, m)
	}
	return (x%m + m) % m, nil // Ensure non-negative result
}

// Struct to store cipher parameters.
type CipherParams struct {
	Operation       string
	InputText       string
	InputTextHelper string
	InputKey        string
	OutputText      string
	OutputKey       string
	CipherType      string
	CipherFunc      func(string, int, int, string) (string, error)
	KeyFinder       func(string, string) (int, int)
}

// ------------------------------------------------------------------------General functions------------------------------------------------------------------------
// Generic function to handle both Caesar and Affine ciphers
func ExecuteCipher(cipherType string, operation string) {
	params := CipherParams{
		Operation:  operation,
		CipherType: cipherType,
	}

	switch operation {
	case "e":
		// Program szyfrujący czyta tekst jawny i klucz i zapisuje tekst zaszyfrowany. Jeśli klucz jest nieprawidłowy, zgłasza jedynie błąd.
		params.InputText = "files/plain.txt"
		params.InputKey = "files/key.txt"
		params.OutputText = "files/crypto.txt"
	case "d":
		// Program odszyfrowujący czyta tekst zaszyfrowany i klucz i zapisuje tekst jawny. Jeśli klucz jest nieprawidłowy, zgłasza błąd.
		// Dla szyfru afinicznego częścią zadania jest znalezienie odwrotności dla liczby a podanej jako część klucza –
		// nie można zakładać, że program odszyfrowujący otrzymuje tę odwrotność.
		params.InputText = "files/crypto.txt"
		params.InputKey = "files/key.txt"
		params.OutputText = "files/decrypt.txt"
	case "j":
		// Program łamiący szyfr z pomocą tekstu jawnego czyta tekst zaszyfrowany, tekst pomocniczy. Następnie zapisuje znaleziony klucz i odszyfrowany tekst.
		// Jeśli niemożliwe jest znalezienie klucza, zgłasza sygnał błędu.
		params.InputText = "files/crypto.txt"
		params.InputTextHelper = "files/extra.txt"
		params.OutputText = "files/decrypt.txt"
		params.OutputKey = "files/key-found.txt"

		// Ensure extra.txt exists before proceeding
		if _, err := os.Stat("files/extra.txt"); os.IsNotExist(err) {
			//log.Println("Plik extra.txt nie istnieje, tworzenie go...")
			if err := CreateExtraFile(); err != nil {
				log.Fatalf("Błąd przy tworzeniu pliku extra.txt: %v", err)
			}
		}

		// If Caesar explicit cryptanalysis (-c -j), call specialized function
		if cipherType == "caesar" {
			CaesarExplicitCryptAnalysis(params.InputText, params.InputTextHelper, params.OutputText, params.OutputKey)
			return
		} else if cipherType == "affine" {
			AffineExplicitCryptAnalysis(params.InputText, params.InputTextHelper, params.OutputText, params.OutputKey)
			return
		}

	case "k":
		//Program łamiący szyfr bez pomocy tekstu jawnego czyta jedynie tekst zaszyfrowany i zapisuje jako tekst odszyfrowany wszystkie możliwe kandydatury (25 dla szyfru Cezara, 311 dla szyfru afinicznego).
		params.InputText = "files/crypto.txt"
		params.OutputText = "files/decrypt.txt"
		// If Caesar explicit cryptanalysis (-c -k), call specialized function
		if cipherType == "caesar" {
			CaesarCryptAnalysis(params.InputText, params.OutputText)
			return
		} else if cipherType == "affine" {
			AffineCryptAnalysis(params.InputText, params.OutputText)
			return
		}
	default:
		fmt.Println("Nieobsługiwana operacja.")
		return
	}

	// Assign cipher-specific functions
	switch cipherType {
	case "caesar":
		params.CipherFunc = CaesarCipher
		params.KeyFinder = FindCaesarKey
	case "affine":
		params.CipherFunc = AffineCipher
		params.KeyFinder = FindAffineKey
	default:
		fmt.Println("Nieobsługiwany typ szyfru.")
		return
	}

	// Execute the cipher operation
	CipherOperations(params)
}

// Generic cipher function for both Caesar and Affine ciphers
func CipherOperations(params CipherParams) {
	// Read the input text.
	textLines, err := GetText(params.InputText)
	if err != nil {
		log.Fatalf("Błąd odczytu pliku: %v", err)
	}
	originalText := strings.Join(textLines, "\n")

	var c, a int

	switch params.Operation {
	case "e", "d":
		// Validate the key.
		c, a = ValidateKey(params.InputKey, params.CipherType)
		//fmt.Printf("Klucz: %d %d\n", c, a)
	case "j":
		// Read the extra text.
		extraTextLines, err := GetText(params.InputTextHelper)
		if err != nil {
			log.Fatalf("Błąd odczytu pliku pomocniczego: %v", err)
		}
		extraText := strings.Join(extraTextLines, "\n")

		// Find the key based on the extra text.
		c, a = params.KeyFinder(originalText, extraText)

		// Save the key to a file.
		SaveOutput(fmt.Sprintf("%d %d", c, a), params.OutputKey)
	default:
		log.Fatalf("Nieznana operacja: %s", params.Operation)
	}

	// Execute the cipher function based on the cipher type
	var resultText string
	var cipherErr error

	switch params.CipherType {
	case "caesar":
		// If it's Caesar, use CaesarCipher
		resultText, cipherErr = CaesarCipher(originalText, a, c, params.Operation)
	case "affine":
		// If it's Affine, use AffineCipher
		resultText, cipherErr = AffineCipher(originalText, a, c, params.Operation)
	default:
		log.Fatalf("Nieobsługiwany typ szyfru: %s", params.CipherType)
	}

	if cipherErr != nil {
		log.Fatalf("Błąd szyfrowania: %v", cipherErr)
	}

	// Save the result to a file.
	SaveOutput(resultText, params.OutputText)

}

// ------------------------------------------------------------------------Caesar Cipher------------------------------------------------------------------------
// CaesarCipher encrypts or decrypts text using the Caesar cipher based on the given flags.
func CaesarCipher(text string, _, c int, operation string) (string, error) {
	var result strings.Builder
	//fmt.Printf("CaesarCipher: c=%d, operation=%s\n", c, operation)

	if operation != "e" && operation != "d" {
		return "", fmt.Errorf("nieprawidłowa operacja: %s", operation)
	}

	if len(text) == 0 {
		return "", fmt.Errorf("tekst wejściowy jest pusty")
	}

	for _, char := range text {
		// Handle encryption for lowercase letters and uppercase letters
		if operation == "e" {
			if char >= 'a' && char <= 'z' {
				shift := int(char - 'a')  
				shift = (shift + c) % 26  
				result.WriteRune(rune(shift + 'a')) 
			} else if char >= 'A' && char <= 'Z' {
				shift := int(char - 'A')  
				shift = (shift + c) % 26  
				result.WriteRune(rune(shift + 'A')) 
			}
		}

		// Handle decryption for lowercase letters and uppercase letters
		if operation == "d" {
			if char >= 'a' && char <= 'z' {
				shift := int(char - 'a')  
				shift = (shift - c + 26) % 26  
				result.WriteRune(rune(shift + 'a'))  
			} else if char >= 'A' && char <= 'Z' {
				shift := int(char - 'A') 
				shift = (shift - c + 26) % 26  
				result.WriteRune(rune(shift + 'A')) 
			}
		}

		// Non-alphabet characters remain unchanged
		if !(char >= 'a' && char <= 'z' || char >= 'A' && char <= 'Z') {
			result.WriteRune(char) 
		}
	}

	return result.String(), nil
}

// FindCaesarKey calculates the Caesar cipher key based on the first matching characters in the ciphertext and extra text.
func FindCaesarKey(cryptoText, extraText string) (int, int) {
	// Znajdujemy pierwszy pasujący znak w obu tekstach
	for i := 0; i < len(extraText) && i < len(cryptoText); i++ {
		cipherChar := cryptoText[i]
		plainChar := extraText[i]

		if (cipherChar >= 'A' && cipherChar <= 'Z' && plainChar >= 'A' && plainChar <= 'Z') ||
			(cipherChar >= 'a' && cipherChar <= 'z' && plainChar >= 'a' && plainChar <= 'z') {

			// Calculate the key based on the difference between the characters
			key := int(cipherChar - plainChar)

			// Key must be between 0 and 25
			if key < 0 {
				key += 26
			}
			return key, 1
		}
	}

	log.Fatal("Nie udało się znaleźć pasujących znaków do odgadnięcia klucza.")
	return -1, 1
}

// CaesarExplicitCryptAnalysis make analysis of Caesar cipher based on the extra text.
func CaesarExplicitCryptAnalysis(inputText, inputTextHelper, outputText, outputKey string) {
	// Read the entire ciphertext.
	cryptoLines, err := GetText(inputText)
	if err != nil {
		log.Fatalf("Błąd przy odczycie pliku %s: %v", inputText, err)
	}
	cryptoText := strings.Join(cryptoLines, "\n")
	//fmt.Printf("Oczekiwany zaszyfrowany tekst: %s\n", cryptoText)

	// Read the extra text.
	extraLines, err := GetText(inputTextHelper)
	if err != nil {
		log.Fatalf("Błąd przy odczycie pliku %s: %v", inputTextHelper, err)
	}
	extraText := strings.Join(extraLines, "\n")
	//fmt.Printf("Oczekiwany jawny tekst pomocniczy: %s\n", extraText)

	if len(cryptoText) == 0 || len(extraText) == 0 {
		log.Fatal("Błąd: Brak danych w plikach wejściowych.")
	}

	// Guess the Caesar key by comparing characters
	guessedKey := (int(cryptoText[0]) - int(extraText[0]) + 26) % 26
	guessedKeyString := strconv.Itoa(guessedKey)

	// Save the guessed key
	SaveOutput(guessedKeyString + " 1", outputKey)

	// Decrypt using the guessed key
	decryptedText, _ := CaesarCipher(cryptoText, -1, guessedKey, "d")

	SaveOutput(decryptedText, outputText)
}

func CaesarCryptAnalysis(inputText string, outputText string) {
	// Read the entire ciphertext.
	cryptoLines, err := GetText(inputText)
	if err != nil {
		log.Fatalf("Błąd przy odczycie pliku %s: %v", inputText, err)
	}
	cryptoText := strings.Join(cryptoLines, "\n")

	if len(cryptoText) == 0 {
		log.Fatal("Błąd: Brak danych w pliku wejściowym.")
	}

	var result strings.Builder

	// Test all possible keys (0-25)
	for key := 1; key <= 25; key++ {
		decryptedText, _ := CaesarCipher(cryptoText, -1, key, "d")
		result.WriteString(decryptedText + "\n")
	}

	SaveOutput(result.String(), outputText)
}

// ------------------------------------------------------------------------Affine Cipher------------------------------------------------------------------------
// Affine cipher function
func AffineCipher(text string, a, c int, operation string) (string, error) {
	m := 26
	var result string

	//fmt.Printf("AffineCipher: a=%d, c=%d, operation=%s\n", a, c, operation)
	//fmt.Printf("Input text: %s\n", text)

	// Calculate the modular inverse of 'a' if decrypting
	aInv := 0
	if operation == "d" {
		var err error
		aInv, err = ModInverseExtended(a, m)
		if err != nil {
			return "", fmt.Errorf("nie można odszyfrować: %v", err)
		}
	}

	// Process each character
	for _, char := range text {
		if unicode.IsLetter(char) && unicode.Is(unicode.Latin, char) { // Only process Latin letters
			isUpper := unicode.IsUpper(char)
			base := 'a'
			if isUpper {
				base = 'A'
			}

			x := int(char - base) // Convert to numerical value (0-25)

			if operation == "e" { // Encrypt
				y := (a*x + c) % m
				result += string(rune(y) + base)
			} else if operation == "d" { // Decrypt
				y := (aInv * ((x - c + m) % m)) % m
				result += string(rune(y) + base)
			}
		} else {
			result += string(char) // Leave non-letter characters unchanged
		}
	}

	return result, nil
}

// FindAffineKey finds the affine cipher key based on the first matching characters in the ciphertext and extra text.
func FindAffineKey(cryptoText, extraText string) (int, int) {

	// Find the first matching pair of characters in both texts
	for i := 0; i < len(cryptoText)-1; i++ {
		// Convert characters to zero-based indices (0-25)
		x1 := int(unicode.ToUpper(rune(extraText[i])) - 'A')
		y1 := int(unicode.ToUpper(rune(cryptoText[i])) - 'A')

		x2 := int(unicode.ToUpper(rune(extraText[i+1])) - 'A')
		y2 := int(unicode.ToUpper(rune(cryptoText[i+1])) - 'A')

		//fmt.Printf("x1: %d, y1: %d, x2: %d, y2: %d\n", x1, y1, x2, y2)

		a, c, err := solveAffineSystemSr(x1, x2, y1, y2)
		if err != nil {
			log.Fatal("Nie udało się znaleźć poprawnych wartości a i c:", err)
		}

		return a, c
	}

	log.Fatal("Nie udało się znaleźć odpowiednich par do rozwiązania układu równań.")
	return -1, -1
}

// solveAffineSystemSr solves the system of two affine equations to find the key for the affine cipher.
func solveAffineSystemSr(x1, x2, y1, y2 int) (int, int, error) {
	m := 26
	//fmt.Printf("solveAffineSystem: x1=%d, x2=%d, y1=%d, y2=%d\n", x1, x2, y1, y2)
	// Calculate the differences.
	deltaY := (y1 - y2 + m) % m // ex.15 - 16 = -1 -> mod 26 -> 25
	deltaX := (x1 - x2 + m) % m //ex 8 - 5 = 3
	//fmt.Printf("deltaY: %d, deltaX: %d\n", deltaY, deltaX)

	// Find the modular inverse of deltaX (3 mod 26)
	invDeltaX, err := ModInverseExtended(deltaX, m)
	//fmt.Printf("invDeltaX: %d\n", invDeltaX)
	if err != nil {
		return -1, -1, fmt.Errorf("nie można znaleźć odwrotności modularnej: %v", err)
	}

	x := (deltaY * invDeltaX) % m // x = (25 * 9) mod 26
	//fmt.Printf("Obliczone a: %d\n", x)

	// Calculate y from the first equation: y = 15 - x * 8 mod 26
	y := (y1 - x*x1) % m
	if y < 0 {
		y += m
	}
	//.Printf("Obliczone c: %d\n", y)

	return x, y, nil
}

// Function to break the Affine cipher using known plaintext (extra text)
func AffineExplicitCryptAnalysis(inputText, inputTextHelper, outputText, outputKey string) {
	// Read the entire ciphertext.
	cryptoLines, err := GetText(inputText)
	if err != nil {
		log.Fatalf("Błąd przy odczycie pliku %s: %v", inputText, err)
	}
	cryptoText := strings.Join(cryptoLines, "\n")
	//fmt.Printf("Oczekiwany zaszyfrowany cryptoText: %s\n", cryptoText)

	// Read the extra text (known plaintext).
	extraLines, err := GetText(inputTextHelper)
	if err != nil {
		log.Fatalf("Błąd przy odczycie pliku %s: %v", inputTextHelper, err)
	}
	extraText := strings.Join(extraLines, "\n")
	//fmt.Printf("Oczekiwany jawny extraText: %s\n", extraText)

	if len(cryptoText) == 0 || len(extraText) == 0 {
		log.Fatal("Błąd: Brak danych w plikach wejściowych.")
	}

	// Find the affine cipher key based on the known plaintext
	a, c := FindAffineKey(cryptoText, extraText)
	//fmt.Printf("Znaleziony klucz: a=%d, c=%d\n", a, c)

	// Save the key (a, c) to the output key file
	SaveOutput(fmt.Sprintf("%d %d", c, a), outputKey)

	// Decrypt the ciphertext using the found key
	decryptedText, err := AffineCipher(cryptoText, a, c, "d")
	if err != nil {
		log.Fatalf("Błąd odszyfrowania: %v", err)
	}
	//fmt.Printf("Odszyfrowany tekst: %s\n", decryptedText)

	// Save the decrypted text to the output file
	SaveOutput(decryptedText, outputText)
}

// AffineCryptAnalysis tests all possible keys (a, c) for the affine cipher and saves all decrypted texts.
func AffineCryptAnalysis(inputText string, outputText string) {
	m := 26
	var result strings.Builder

	// Read the entire ciphertext
	cryptoLines, err := GetText(inputText)
	if err != nil {
		log.Fatalf("Błąd przy odczycie pliku %s: %v", inputText, err)
	}
	cryptoText := strings.Join(cryptoLines, "\n")
	//fmt.Printf("Oczekiwany zaszyfrowany tekst: %s\n", cryptoText)

	// Check if the ciphertext is empty
	if len(cryptoText) == 0 {
		log.Fatal("Błąd: Brak danych w pliku wejściowym.")
	}

	// Check all possible combinations of a (1-25) and c (0-25) for the affine cipher
	for a := 0; a < m; a++ {
		// Check if 'a' is coprime with 26 (i.e., gcd(a, 26) == 1)
		gcd, _, _ := ExtendedGCD(a, m)
		if gcd == 1 {
			for c := 0; c < m; c++ {
				// Skip the key (1, 0), as it does not alter the text
				if a == 1 && c == 0 {
					continue
				}

				// Decrypt the text using the affine cipher with key (a, c)
				decryptedText, err := AffineCipher(cryptoText, a, c, "d")
				if err != nil {
					log.Fatalf("Błąd odszyfrowania: %v", err)
				}
				//fmt.Printf("Próba: a=%d, c=%d\n odszyfrowany tekst: %s\n\n", a, c, decryptedText)

				// Save the decrypted text
				result.WriteString(fmt.Sprintf("%s\n", decryptedText))
			}
		}
	}

	SaveOutput(result.String(), outputText)
}

func main() {
	//Set flags
	caesarFlag := flag.Bool("c", false, "szyfr cezara")
	affineFlag := flag.Bool("a", false, "szyfr afiniczny")

	encryptFlag := flag.Bool("e", false, "szyfrowanie")
	decryptFlag := flag.Bool("d", false, "deszyfrowanie")
	explicitCryptAnalysisFlag := flag.Bool("j", false, "kryptoanaliza z tekstem jawnym")
	cryptAnalysisFlag := flag.Bool("k", false, "kryptoanaliza wyłącznie w oparciu o kryptogram")

	flag.Parse()

	// Check flags
	cipherFlags := []*bool{caesarFlag, affineFlag}
	operationFlags := []*bool{encryptFlag, decryptFlag, explicitCryptAnalysisFlag, cryptAnalysisFlag}

	cipherCount := CountSelectedFlags(cipherFlags)
	operationCount := CountSelectedFlags(operationFlags)

	if cipherCount != 1 {
		fmt.Println("Błąd: Musisz wybrać dokładnie jeden rodzaj szyfru (-c lub -a).")
		os.Exit(1)
	}

	if operationCount != 1 {
		fmt.Println("Błąd: Musisz wybrać dokładnie jedną operację (-e, -d, -j lub -k).")
		os.Exit(1)
	}


	// Determine the cipher type
	var cipherType string
	if *caesarFlag {
		cipherType = "caesar"
	} else if *affineFlag {
		cipherType = "affine"
	} else {
		log.Fatal("Błąd: Nie wybrano poprawnego szyfru (-c dla Cezara, -a dla afinicznego).")
	}

	// Determine the operation
	var operation string
	switch {
	case *encryptFlag:
		operation = "e"
	case *decryptFlag:
		operation = "d"
	case *explicitCryptAnalysisFlag:
		operation = "j"
	case *cryptAnalysisFlag:
		operation = "k"
	default:
		fmt.Println("Błąd: Nie wybrano poprawnej operacji (-e, -d, -j, -k).")
		os.Exit(1)
	}

	// Execute the cipher operation
	ExecuteCipher(cipherType, operation)

}